#ifndef ABBREVIATIONS_H
#define ABBREVIATIONS_H

#define THROW_EXCEPTION(excptn, msg) throw excptn(msg, __FILE__, __LINE__)

#endif
