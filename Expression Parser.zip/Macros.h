#ifndef MACROS_H
#define MACROS_H

//Currently no macros, probably never will be. Most macr

#endif
