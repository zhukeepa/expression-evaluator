#ifndef EXPRESSIONTREENODE_H
#define EXPRESSIONTREENODE_H

/**
  * THIS FILE IS NOT MEANT TO BE INCLUDED BY THE USER. THIS IS A PRIVATE, NESTED
  * CLASS; ITS IMPLEMENTATION IS LONG, SO THE DEVELOPER HAS DECIDED TO
  * #INCLUDE IT WITHIN THE CLASS.
  */

//This is going to be wrapped in namespace MBEP, as it will be #include'd inside
//the namespace.



#endif
