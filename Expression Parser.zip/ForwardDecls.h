#ifndef FORWARDECLS_H
#define FORWARDECLS_H

namespace mpw
{
    class String;
}

#endif
